#ifndef RACING_CAR_GAME_H
#define RACING_CAR_GAME_H


#include <stdio.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_ttf.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "variable.h"
#include "fonction.h"



int game1(FILE*);

int game2(FILE*);

#endif
