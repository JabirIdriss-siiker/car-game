RACING CAR EST UN JEU DE voiture crée par JABIR IDRISS avec SDL2

pour lancer le jeu il suffit de taper make
puis ./car suivie du nom du fichier du circuit .txt

il y deux modes de jeu
1/- meilleur temps c'est un mode de jeu classique ou il faut faire 3 tours de circuit dans le meilleur temps possible
2/- contre la montre c'est un mode de jeu ou il faut faire les 3 tours du circuit avant 30 secondes

Les déplacements:
pour se déplacer sur le circuit les commandes sont simples:

-flèche de haut pour accélérer
-flèche de bas pour ralentir et revenir en arrière
-flèche de gauche et droite pour tourner
